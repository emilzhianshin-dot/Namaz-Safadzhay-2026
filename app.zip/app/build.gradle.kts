plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}

android {
    namespace = "ru.namaz.safadzhay"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.namaz.safadzhay"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }
}

kotlin {
    jvmToolchain(17)
}
