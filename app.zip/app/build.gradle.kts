plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.namaz.safadzhay"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.namaz.safadzhay"
        minSdk = 23
        targetSdk = 35
        versionCode = 28
        versionName = "1.0"
    }

    signingConfigs {
        create("namazRelease") {
            storeFile = file("namaz-release.jks")
            storePassword = "NamazSafadzhay2026"
            keyAlias = "namaz"
            keyPassword = "NamazSafadzhay2026"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("namazRelease")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.2")
}
