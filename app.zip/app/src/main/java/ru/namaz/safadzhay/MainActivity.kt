package ru.namaz.safadzhay

import android.Manifest
import android.app.*
import android.content.*
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

data class Prayer(val ru: String, val tt: String, val time: String)

class MainActivity : Activity() {
    private val bg = Color.rgb(0, 28, 20)
    private val card = Color.rgb(8, 48, 38)
    private val accent = Color.rgb(82, 221, 159)
    private val secondary = Color.rgb(174, 205, 195)

    private lateinit var root: LinearLayout
    private lateinit var countdown: TextView
    private lateinit var nextTitle: TextView
    private lateinit var progress: ProgressBar
    private lateinit var dateViewRef: TextView
    private var timer: CountDownTimer? = null

    private val safadzhay = listOf(
        "02:38", "12:20", "16:40", "19:43", "21:30"
    )
    private val moscow = listOf(
        "03:34", "12:20", "16:06", "18:55", "20:25"
    )
    private val names = arrayOf(
        "Фаджр" to "Иртәнге намаз",
        "Зухр" to "Өйлә намазы",
        "Аср" to "Икенде намазы",
        "Магриб" to "Ахшам намазы",
        "Иша" to "Ястү намазы"
    )

    private var city = "Москва"
    private var tahajjud = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        }

        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != 0) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        scheduleNotifications()
        update()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            setBackgroundColor(bg)
            setPadding(dp(30), dp(20), dp(30), dp(8))
        }

        val header = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(235))
        }

        val title = tv("НАМАЗ", 42f, Color.WHITE, true).apply {
            layoutParams = FrameLayout.LayoutParams(-1, dp(62), Gravity.TOP)
        }
        header.addView(title)

        val gear = TextView(this).apply {
            text = "⚙"
            textSize = 30f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            setOnClickListener { showSettings() }
            layoutParams = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.END)
        }
        header.addView(gear)

        val cityView = tv(city.uppercase(Locale.getDefault()), 25f, accent, true).apply {
            layoutParams = FrameLayout.LayoutParams(-1, dp(42)).apply {
                topMargin = dp(68)
            }
        }
        header.addView(cityView)

        val dateView = tv("", 25f, secondary).apply {
            layoutParams = FrameLayout.LayoutParams(-1, dp(38)).apply {
                topMargin = dp(112)
            }
        }
        header.addView(dateView)
        dateViewRef = dateView

        val hijriView = tv("19 Раби аль-авваль 1448 г. х.", 22f, secondary).apply {
            layoutParams = FrameLayout.LayoutParams(-1, dp(36)).apply {
                topMargin = dp(148)
            }
        }
        header.addView(hijriView)

        val nowView = tv("", 22f, secondary, true).apply {
            layoutParams = FrameLayout.LayoutParams(-1, dp(34)).apply {
                topMargin = dp(184)
            }
        }
        header.addView(nowView)

        root.addView(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, dp(44))
        }
        tabs.addView(tv("СЕГОДНЯ", 18f, accent, true), LinearLayout.LayoutParams(0, -1, 1f))
        tabs.addView(tv("РАСПИСАНИЕ", 18f, secondary, true), LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(tabs)

        val countdownCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(card, dp(26), accent, dp(2))
            layoutParams = LinearLayout.LayoutParams(-1, dp(285)).apply {
                topMargin = dp(8)
                bottomMargin = dp(10)
            }
        }

        nextTitle = tv("", 28f, Color.WHITE, true)
        countdownCard.addView(nextTitle, LinearLayout.LayoutParams(-1, dp(42)))

        countdown = tv("00:00:00", 55f, accent, true)
        countdownCard.addView(countdown, LinearLayout.LayoutParams(-1, dp(72)))

        val label = tv("До намаза осталось", 23f, secondary)
        countdownCard.addView(label, LinearLayout.LayoutParams(-1, dp(32)))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 500
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            layoutParams = LinearLayout.LayoutParams(dp(190), dp(5)).apply {
                topMargin = dp(12)
            }
        }
        countdownCard.addView(progress)

        root.addView(countdownCard)

        val prayers = moscow
        prayers.forEachIndexed { i, time ->
            root.addView(prayerCard(names[i].first, names[i].second, time, i))
        }

        setContentView(root)

        Handler(Looper.getMainLooper()).post(object : Runnable {
            override fun run() {
                dateViewRef.text = SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date())
                nowView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                update()
                Handler(Looper.getMainLooper()).postDelayed(this, 1000)
            }
        })
    }

    private fun prayerCard(ru: String, tt: String, time: String, index: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(7), dp(28), dp(7))
            background = rounded(
                if (index == currentPrayerIndex()) Color.rgb(14, 92, 68) else Color.rgb(6, 39, 31),
                if (index == currentPrayerIndex()) accent else Color.rgb(36, 70, 62),
                dp(24),
                if (index == currentPrayerIndex()) dp(2) else dp(1)
            )
            layoutParams = LinearLayout.LayoutParams(-1, dp(82)).apply {
                bottomMargin = dp(8)
            }
        }
        val namesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
        }
        namesBox.addView(tv(ru, 25f, if (index < currentPrayerIndex()) secondary else Color.WHITE, true),
            LinearLayout.LayoutParams(-1, dp(34)).apply { gravity = Gravity.START })
        namesBox.addView(tv("($tt)", 21f, secondary),
            LinearLayout.LayoutParams(-1, dp(30)).apply { gravity = Gravity.START })
        box.addView(namesBox)
        box.addView(tv(time, 28f, if (index == currentPrayerIndex()) accent else Color.WHITE, true),
            LinearLayout.LayoutParams(dp(112), -1))
        return box
    }

    private fun currentPrayerIndex(): Int {
        val times = moscow.map { it.split(":").let { p -> p[0].toInt()*60+p[1].toInt() } }
        val now = Calendar.getInstance().let { it.get(Calendar.HOUR_OF_DAY)*60+it.get(Calendar.MINUTE) }
        return times.indexOfFirst { now < it }.let { if (it == -1) 0 else it }
    }

    private fun update() {
        if (!::countdown.isInitialized) return
        val times = moscow.map { it.split(":").let { p -> p[0].toInt()*60+p[1].toInt() } }
        val nowCal = Calendar.getInstance()
        val nowSec = nowCal.get(Calendar.HOUR_OF_DAY)*3600 + nowCal.get(Calendar.MINUTE)*60 + nowCal.get(Calendar.SECOND)
        var idx = -1
        var target = 0
        for (i in times.indices) {
            val sec = times[i] * 60
            if (sec > nowSec) { idx = i; target = sec; break }
        }
        if (idx == -1) {
            idx = 0
            target = times[0]*60 + 86400
        }
        nextTitle.text = "${names[idx].first} (${names[idx].second})"
        val remaining = target - nowSec
        countdown.text = String.format(Locale.getDefault(), "%02d:%02d:%02d",
            remaining/3600, (remaining%3600)/60, remaining%60)
        progress.progress = max(0, 1000 - (remaining % 3600) * 1000 / 3600)
    }

    private fun rounded(color: Int, stroke: Int, radius: Int, width: Int): android.graphics.drawable.Drawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(width, stroke)
        }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(10), dp(24), dp(10))
        }
        val city = tv("Город", 22f, Color.WHITE, true)
        box.addView(city, LinearLayout.LayoutParams(-1, dp(45)))
        listOf("Сафаджай", "Москва").forEach { c ->
            val b = Button(this).apply {
                text = c
                setOnClickListener {
                    this@MainActivity.city = c
                    Toast.makeText(this@MainActivity, "Выбран $c", Toast.LENGTH_SHORT).show()
                }
            }
            box.addView(b, LinearLayout.LayoutParams(-1, dp(50)))
        }

        val tah = Switch(this).apply {
            text = "Показывать Тахаджуд"
            setTextColor(Color.WHITE)
            isChecked = tahajjud
            setOnCheckedChangeListener { _, v -> tahajjud = v }
        }
        box.addView(tah)

        val about = Button(this).apply {
            text = "О приложении"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Намаз")
                    .setMessage("Приложение для личного использования\nВерсия 2.1")
                    .setPositiveButton("OK", null).show()
            }
        }
        box.addView(about)

        AlertDialog.Builder(this)
            .setTitle("Настройки")
            .setView(box)
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun scheduleNotifications() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val times = moscow
        val namesIds = names
        for (i in times.indices) {
            val p = times[i].split(":")
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, p[0].toInt())
                set(Calendar.MINUTE, p[1].toInt())
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, -5)
                if (timeInPast(this)) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(this, PrayerAlarmReceiver::class.java).apply {
                putExtra("name", namesIds[i].first)
                putExtra("tt", namesIds[i].second)
                putExtra("time", times[i])
                putExtra("id", 500+i)
            }
            val pi = PendingIntent.getBroadcast(
                this, 500+i, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }

    private fun timeInPast(c: Calendar): Boolean = c.timeInMillis <= System.currentTimeMillis()
}
