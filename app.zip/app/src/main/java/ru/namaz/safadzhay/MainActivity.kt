package ru.namaz.safadzhay

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.Duration

data class PrayerDay(
    val date: String,
    val fajr: String,
    val zuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String
)

data class Prayer(val name: String, val tatar: String, val time: String)

class MainActivity : Activity() {
    private val zone = ZoneId.of("Europe/Moscow")
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var countdown: TextView
    private lateinit var nextName: TextView
    private lateinit var nextTime: TextView
    private lateinit var dateText: TextView
    private lateinit var prayerList: LinearLayout

    private val data = listOf(
        PrayerDay("2026-08-01", "02:14", "12:20", "16:55", "20:06", "21:56"),
        PrayerDay("2026-08-02", "02:16", "12:20", "16:54", "20:04", "21:54"),
        PrayerDay("2026-08-03", "02:18", "12:20", "16:53", "20:02", "21:52"),
        PrayerDay("2026-08-04", "02:20", "12:20", "16:51", "20:00", "21:50"),
        PrayerDay("2026-08-05", "02:22", "12:20", "16:50", "19:58", "21:48"),
        PrayerDay("2026-08-06", "02:24", "12:20", "16:49", "19:56", "21:46"),
        PrayerDay("2026-08-07", "02:26", "12:20", "16:47", "19:54", "21:44"),
        PrayerDay("2026-08-08", "02:28", "12:20", "16:46", "19:52", "21:42"),
        PrayerDay("2026-08-09", "02:29", "12:20", "16:44", "19:50", "21:40"),
        PrayerDay("2026-08-10", "02:32", "12:20", "16:42", "19:47", "21:36"),
        PrayerDay("2026-08-11", "02:35", "12:20", "16:41", "19:45", "21:33"),
        PrayerDay("2026-08-12", "02:38", "12:20", "16:40", "19:43", "21:30"),
        PrayerDay("2026-08-13", "02:42", "12:20", "16:38", "19:41", "21:26"),
        PrayerDay("2026-08-14", "02:44", "12:20", "16:37", "19:39", "21:24"),
        PrayerDay("2026-08-15", "02:48", "12:20", "16:35", "19:36", "21:19"),
        PrayerDay("2026-08-16", "02:50", "12:20", "16:33", "19:34", "21:17"),
        PrayerDay("2026-08-17", "02:53", "12:20", "16:32", "19:32", "21:14"),
        PrayerDay("2026-08-18", "02:57", "12:20", "16:30", "19:29", "21:09"),
        PrayerDay("2026-08-19", "02:59", "12:20", "16:29", "19:27", "21:07"),
        PrayerDay("2026-08-20", "03:02", "12:20", "16:27", "19:25", "21:04"),
        PrayerDay("2026-08-21", "03:04", "12:20", "16:25", "19:22", "21:00"),
        PrayerDay("2026-08-22", "03:07", "12:20", "16:24", "19:20", "20:57"),
        PrayerDay("2026-08-23", "03:10", "12:20", "16:21", "19:17", "20:53"),
        PrayerDay("2026-08-24", "03:12", "12:20", "16:20", "19:15", "20:51"),
        PrayerDay("2026-08-25", "03:15", "12:20", "16:19", "19:13", "20:48"),
        PrayerDay("2026-08-26", "03:19", "12:20", "16:17", "19:10", "20:43"),
        PrayerDay("2026-08-27", "03:21", "12:20", "16:15", "19:08", "20:41"),
        PrayerDay("2026-08-28", "03:24", "12:20", "16:13", "19:05", "20:37"),
        PrayerDay("2026-08-29", "03:26", "12:20", "16:12", "19:03", "20:35"),
        PrayerDay("2026-08-30", "03:29", "12:20", "16:10", "19:00", "20:31"),
        PrayerDay("2026-08-31", "03:32", "12:20", "16:08", "18:58", "20:28"),
        PrayerDay("2026-09-01", "03:34", "12:20", "16:06", "18:55", "20:25"),
        PrayerDay("2026-09-02", "03:36", "12:20", "16:04", "18:52", "20:22"),
        PrayerDay("2026-09-03", "03:37", "12:20", "16:02", "18:50", "20:20"),
        PrayerDay("2026-09-04", "03:39", "12:20", "16:00", "18:47", "20:17"),
        PrayerDay("2026-09-05", "03:42", "12:20", "15:59", "18:45", "20:14"),
        PrayerDay("2026-09-06", "03:44", "12:20", "15:57", "18:42", "20:11"),
        PrayerDay("2026-09-07", "03:48", "12:20", "15:55", "18:40", "20:07"),
        PrayerDay("2026-09-08", "03:50", "12:20", "15:53", "18:37", "20:04"),
        PrayerDay("2026-09-09", "03:53", "12:20", "15:51", "18:34", "20:00"),
        PrayerDay("2026-09-10", "03:55", "12:20", "15:50", "18:32", "19:58"),
        PrayerDay("2026-09-11", "03:57", "12:20", "15:48", "18:29", "19:55"),
        PrayerDay("2026-09-12", "04:00", "12:20", "15:46", "18:27", "19:52"),
        PrayerDay("2026-09-13", "04:01", "12:20", "15:44", "18:24", "19:49"),
        PrayerDay("2026-09-14", "04:03", "12:20", "15:42", "18:21", "19:46"),
        PrayerDay("2026-09-15", "04:05", "12:20", "15:40", "18:19", "19:44"),
        PrayerDay("2026-09-16", "04:07", "12:20", "15:38", "18:16", "19:41"),
        PrayerDay("2026-09-17", "04:09", "12:20", "15:36", "18:13", "19:38"),
        PrayerDay("2026-09-18", "04:11", "12:20", "15:35", "18:11", "19:36"),
        PrayerDay("2026-09-19", "04:13", "12:20", "15:33", "18:08", "19:33"),
        PrayerDay("2026-09-20", "04:15", "12:20", "15:30", "18:05", "19:30"),
        PrayerDay("2026-09-21", "04:17", "12:20", "15:29", "18:03", "19:28"),
        PrayerDay("2026-09-22", "04:18", "12:20", "15:27", "18:00", "19:25"),
        PrayerDay("2026-09-23", "04:20", "12:20", "15:25", "17:58", "19:23"),
        PrayerDay("2026-09-24", "04:22", "12:20", "15:23", "17:55", "19:20"),
        PrayerDay("2026-09-25", "04:24", "12:20", "15:21", "17:52", "19:17"),
        PrayerDay("2026-09-26", "04:26", "12:20", "15:20", "17:50", "19:15"),
        PrayerDay("2026-09-27", "04:28", "12:20", "15:18", "17:47", "19:12"),
        PrayerDay("2026-09-28", "04:30", "12:20", "15:15", "17:44", "19:09"),
        PrayerDay("2026-09-29", "04:32", "12:20", "15:14", "17:42", "19:07"),
        PrayerDay("2026-09-30", "04:34", "12:20", "15:12", "17:39", "19:04"),
        PrayerDay("2026-10-01", "04:36", "12:20", "15:11", "17:37", "19:02"),
        PrayerDay("2026-10-02", "04:38", "12:20", "15:08", "17:34", "18:59"),
        PrayerDay("2026-10-03", "04:40", "12:20", "15:06", "17:31", "18:56"),
        PrayerDay("2026-10-04", "04:42", "12:20", "15:05", "17:29", "18:54"),
        PrayerDay("2026-10-05", "04:44", "12:20", "15:03", "17:26", "18:51"),
        PrayerDay("2026-10-06", "04:45", "12:20", "15:01", "17:24", "18:49"),
        PrayerDay("2026-10-07", "04:47", "12:20", "14:59", "17:21", "18:46"),
        PrayerDay("2026-10-08", "04:49", "12:20", "14:58", "17:19", "18:44"),
        PrayerDay("2026-10-09", "04:51", "12:20", "14:56", "17:16", "18:41"),
        PrayerDay("2026-10-10", "04:53", "12:20", "14:53", "17:13", "18:38"),
        PrayerDay("2026-10-11", "04:55", "12:20", "14:52", "17:11", "18:36"),
        PrayerDay("2026-10-12", "04:57", "12:20", "14:50", "17:08", "18:33"),
        PrayerDay("2026-10-13", "04:59", "12:20", "14:49", "17:06", "18:31"),
        PrayerDay("2026-10-14", "05:01", "12:20", "14:46", "17:03", "18:28"),
        PrayerDay("2026-10-15", "05:03", "12:20", "14:45", "17:01", "18:26"),
        PrayerDay("2026-10-16", "05:05", "12:20", "14:43", "16:58", "18:23"),
        PrayerDay("2026-10-17", "05:07", "12:20", "14:42", "16:56", "18:21"),
        PrayerDay("2026-10-18", "05:09", "12:20", "14:40", "16:54", "18:19"),
        PrayerDay("2026-10-19", "05:11", "12:20", "14:38", "16:51", "18:16"),
        PrayerDay("2026-10-20", "05:14", "12:20", "14:37", "16:49", "18:14"),
        PrayerDay("2026-10-21", "05:16", "12:20", "14:35", "16:46", "18:11"),
        PrayerDay("2026-10-22", "05:18", "12:20", "14:33", "16:44", "18:09"),
        PrayerDay("2026-10-23", "05:20", "12:20", "14:32", "16:42", "18:07"),
        PrayerDay("2026-10-24", "05:22", "12:20", "14:30", "16:39", "18:04"),
        PrayerDay("2026-10-25", "05:24", "12:20", "14:29", "16:37", "18:02"),
        PrayerDay("2026-10-26", "05:26", "12:20", "14:27", "16:35", "18:00"),
        PrayerDay("2026-10-27", "05:28", "12:20", "14:25", "16:32", "17:57"),
        PrayerDay("2026-10-28", "05:30", "12:20", "14:24", "16:30", "17:55"),
        PrayerDay("2026-10-29", "05:32", "12:20", "14:22", "16:28", "17:53"),
        PrayerDay("2026-10-30", "05:34", "12:20", "14:21", "16:26", "17:51"),
        PrayerDay("2026-10-31", "05:36", "12:20", "14:20", "16:24", "17:49"),
        PrayerDay("2026-11-01", "05:38", "12:20", "14:18", "16:22", "17:47"),
        PrayerDay("2026-11-02", "05:41", "12:20", "14:16", "16:19", "17:44"),
        PrayerDay("2026-11-03", "05:42", "12:20", "14:15", "16:17", "17:43"),
        PrayerDay("2026-11-04", "05:44", "12:20", "14:14", "16:15", "17:41"),
        PrayerDay("2026-11-05", "05:46", "12:20", "14:12", "16:13", "17:39"),
        PrayerDay("2026-11-06", "05:48", "12:20", "14:11", "16:11", "17:37"),
        PrayerDay("2026-11-07", "05:50", "12:20", "14:10", "16:09", "17:35"),
        PrayerDay("2026-11-08", "05:52", "12:20", "14:08", "16:07", "17:33"),
        PrayerDay("2026-11-09", "05:53", "12:20", "14:07", "16:05", "17:32"),
        PrayerDay("2026-11-10", "05:55", "12:20", "14:06", "16:03", "17:30"),
        PrayerDay("2026-11-11", "05:57", "12:20", "14:05", "16:02", "17:29"),
        PrayerDay("2026-11-12", "05:59", "12:20", "14:04", "16:00", "17:27"),
        PrayerDay("2026-11-13", "06:02", "12:20", "14:03", "15:58", "17:25"),
        PrayerDay("2026-11-14", "06:03", "12:20", "14:01", "15:56", "17:24"),
        PrayerDay("2026-11-15", "06:03", "12:20", "14:01", "15:55", "17:25"),
        PrayerDay("2026-11-16", "06:05", "12:20", "14:00", "15:53", "17:23"),
        PrayerDay("2026-11-17", "06:07", "12:20", "13:58", "15:51", "17:21"),
        PrayerDay("2026-11-18", "06:09", "12:20", "13:58", "15:50", "17:20"),
        PrayerDay("2026-11-19", "06:11", "12:20", "13:56", "15:48", "17:18"),
        PrayerDay("2026-11-20", "06:13", "12:20", "13:56", "15:47", "17:17"),
        PrayerDay("2026-11-21", "06:15", "12:20", "13:55", "15:45", "17:15"),
        PrayerDay("2026-11-22", "06:17", "12:20", "13:54", "15:44", "17:14"),
        PrayerDay("2026-11-23", "06:18", "12:20", "13:53", "15:42", "17:12"),
        PrayerDay("2026-11-24", "06:20", "12:20", "13:52", "15:41", "17:11"),
        PrayerDay("2026-11-25", "06:22", "12:20", "13:52", "15:40", "17:10"),
        PrayerDay("2026-11-26", "06:24", "12:20", "13:51", "15:39", "17:09"),
        PrayerDay("2026-11-27", "06:26", "12:20", "13:51", "15:38", "17:08"),
        PrayerDay("2026-11-28", "06:28", "12:20", "13:49", "15:36", "17:06"),
        PrayerDay("2026-11-29", "06:29", "12:20", "13:49", "15:35", "17:05"),
        PrayerDay("2026-11-30", "06:31", "12:20", "13:48", "15:34", "17:04"),
        PrayerDay("2026-12-01", "06:31", "12:20", "13:48", "15:33", "17:05"),
        PrayerDay("2026-12-02", "06:30", "12:20", "13:48", "15:33", "17:07"),
        PrayerDay("2026-12-03", "06:32", "12:20", "13:47", "15:32", "17:06"),
        PrayerDay("2026-12-04", "06:33", "12:20", "13:47", "15:31", "17:05"),
        PrayerDay("2026-12-05", "06:35", "12:20", "13:46", "15:30", "17:04"),
        PrayerDay("2026-12-06", "06:36", "12:20", "13:46", "15:30", "17:04"),
        PrayerDay("2026-12-07", "06:36", "12:20", "13:46", "15:29", "17:05"),
        PrayerDay("2026-12-08", "06:37", "12:20", "13:46", "15:29", "17:05"),
        PrayerDay("2026-12-09", "06:37", "12:20", "13:45", "15:28", "17:05"),
        PrayerDay("2026-12-10", "06:39", "12:20", "13:46", "15:28", "17:05"),
        PrayerDay("2026-12-11", "06:40", "12:20", "13:46", "15:28", "17:05"),
        PrayerDay("2026-12-12", "06:40", "12:20", "13:45", "15:27", "17:05"),
        PrayerDay("2026-12-13", "06:41", "12:20", "13:45", "15:27", "17:05"),
        PrayerDay("2026-12-14", "06:42", "12:20", "13:45", "15:27", "17:05"),
        PrayerDay("2026-12-15", "06:43", "12:20", "13:46", "15:27", "17:05"),
        PrayerDay("2026-12-16", "06:44", "12:20", "13:46", "15:27", "17:05"),
        PrayerDay("2026-12-17", "06:45", "12:20", "13:46", "15:27", "17:05"),
        PrayerDay("2026-12-18", "06:45", "12:20", "13:46", "15:27", "17:05"),
        PrayerDay("2026-12-19", "06:46", "12:20", "13:47", "15:28", "17:06"),
        PrayerDay("2026-12-20", "06:47", "12:20", "13:47", "15:28", "17:06"),
        PrayerDay("2026-12-21", "06:47", "12:20", "13:47", "15:28", "17:06"),
        PrayerDay("2026-12-22", "06:48", "12:20", "13:48", "15:29", "17:07"),
        PrayerDay("2026-12-23", "06:48", "12:20", "13:48", "15:29", "17:07"),
        PrayerDay("2026-12-24", "06:49", "12:20", "13:49", "15:30", "17:08"),
        PrayerDay("2026-12-25", "06:49", "12:20", "13:49", "15:30", "17:08"),
        PrayerDay("2026-12-26", "06:49", "12:20", "13:50", "15:31", "17:09"),
        PrayerDay("2026-12-27", "06:49", "12:20", "13:51", "15:32", "17:10"),
        PrayerDay("2026-12-28", "06:50", "12:20", "13:52", "15:33", "17:11"),
        PrayerDay("2026-12-29", "06:50", "12:20", "13:53", "15:34", "17:12"),
        PrayerDay("2026-12-30", "06:50", "12:20", "13:53", "15:35", "17:13"),
        PrayerDay("2026-12-31", "06:49", "12:20", "13:54", "15:36", "17:14")
    )

    private val names = listOf(
        Triple("Фаджр", "Иртәнге намаз", 0),
        Triple("Зухр", "Өйлә намазы", 1),
        Triple("Аср", "Икенде намазы", 2),
        Triple("Магриб", "Ахшам намазы", 3),
        Triple("Иша", "Ястү намазы", 4)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        update()
        handler.postDelayed(object : Runnable {
            override fun run() {
                update()
                handler.postDelayed(this, 1000)
            }
        }, 1000)
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 28, 20))
            setPadding(32, 28, 32, 24)
        }

        val title = tv("НАМАЗ", 30f, Color.WHITE, true)
        root.addView(title, LinearLayout.LayoutParams(-1, 55))

        val place = tv("САФАДЖАЙ", 14f, Color.rgb(57,168,120), true)
        root.addView(place, LinearLayout.LayoutParams(-1, 35))

        dateText = tv("", 16f, Color.rgb(168,200,187), false)
        root.addView(dateText, LinearLayout.LayoutParams(-1, 45))

        nextName = tv("", 24f, Color.WHITE, true)
        root.addView(nextName, LinearLayout.LayoutParams(-1, 60))

        countdown = tv("00:00:00", 56f, Color.rgb(57,168,120), true)
        root.addView(countdown, LinearLayout.LayoutParams(-1, 105))

        nextTime = tv("", 20f, Color.WHITE, false)
        root.addView(nextTime, LinearLayout.LayoutParams(-1, 45))

        val line = TextView(this).apply {
            setBackgroundColor(Color.rgb(14,107,75))
            text = ""
        }
        root.addView(line, LinearLayout.LayoutParams(-1, 2))

        prayerList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 18, 0, 0)
        }
        root.addView(prayerList, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun currentDay(): PrayerDay? {
        val today = LocalDate.now(zone).toString()
        return data.firstOrNull { it.date == today }
    }

    private fun toMinutes(s: String): Int {
        val p = s.split(":")
        return p[0].toInt() * 60 + p[1].toInt()
    }

    private fun getPrayers(day: PrayerDay): List<Prayer> = listOf(
        Prayer(names[0].first, names[0].second, day.fajr),
        Prayer(names[1].first, names[1].second, day.zuhr),
        Prayer(names[2].first, names[2].second, day.asr),
        Prayer(names[3].first, names[3].second, day.maghrib),
        Prayer(names[4].first, names[4].second, day.isha)
    )

    private fun update() {
        val now = LocalDateTime.now(zone)
        val today = currentDay()

        if (today == null) {
            nextName.text = "Расписание"
            countdown.text = "—"
            nextTime.text = "Данные доступны: август–декабрь 2026"
            dateText.text = now.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            return
        }

        dateText.text = now.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        val prayers = getPrayers(today)

        var next: Prayer? = null
        var nextDt: LocalDateTime? = null

        for (p in prayers) {
            val parts = p.time.split(":")
            val dt = now.withHour(parts[0].toInt()).withMinute(parts[1].toInt()).withSecond(0).withNano(0)
            if (dt.isAfter(now)) {
                next = p
                nextDt = dt
                break
            }
        }

        if (next == null) {
            val tomorrow = data.firstOrNull { it.date == now.toLocalDate().plusDays(1).toString() }
            if (tomorrow != null) {
                next = Prayer(names[0].first, names[0].second, tomorrow.fajr)
                val parts = tomorrow.fajr.split(":")
                nextDt = now.plusDays(1).withHour(parts[0].toInt()).withMinute(parts[1].toInt()).withSecond(0).withNano(0)
            }
        }

        if (next != null && nextDt != null) {
            val seconds = Duration.between(now, nextDt).seconds.coerceAtLeast(0)
            countdown.text = String.format("%02d:%02d:%02d", seconds/3600, (seconds%3600)/60, seconds%60)
            nextName.text = "${next!!.name} (${next!!.tatar})"
            nextTime.text = "Начало в ${next!!.time}"
        }

        prayerList.removeAllViews()
        for (p in prayers) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(18, 10, 18, 10)
                setBackgroundColor(Color.rgb(11, 45, 33))
            }
            val label = tv("${p.name} (${p.tatar})", 16f, Color.WHITE, true).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
            }
            val time = tv(p.time, 24f, Color.rgb(57,168,120), true).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
            }
            row.addView(label, LinearLayout.LayoutParams(0, 62, 1f))
            row.addView(time, LinearLayout.LayoutParams(105, 62))
            val lp = LinearLayout.LayoutParams(-1, 68)
            lp.bottomMargin = 8
            prayerList.addView(row, lp)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
